function double_frequencies = get_frequencies(N)
    
    %your code here
end 
